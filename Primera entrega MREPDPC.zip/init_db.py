from __future__ import annotations

from app.database import SessionLocal, bootstrap_database, engine
from app.models import Host
from app.services.config_service import ensure_default_configuration


def init_database() -> None:
    bootstrap_database(engine)

    test_hosts = [
        Host(
            ip="192.168.1.1",
            nombre="Router Local",
            grupo="infraestructura",
            descripcion="Puerta de enlace del laboratorio",
            intervalo_seg=5,
            activo=True,
        ),
        Host(
            ip="8.8.8.8",
            nombre="Google DNS",
            grupo="internet",
            descripcion="Referencia publica para pruebas de conectividad",
            intervalo_seg=10,
            activo=True,
        ),
    ]

    with SessionLocal() as session:
        ensure_default_configuration(session)
        for host in test_hosts:
            exists = session.get(Host, host.ip)
            if exists is None:
                session.add(host)
        session.commit()


if __name__ == "__main__":
    init_database()
    print("Base de datos inicializada correctamente.")
