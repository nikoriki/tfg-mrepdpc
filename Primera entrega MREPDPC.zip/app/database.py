from __future__ import annotations

from pathlib import Path
from typing import Generator

from sqlalchemy import Engine, create_engine, inspect, text
from sqlalchemy.orm import Session, declarative_base, sessionmaker

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
CAPTURES_DIR = BASE_DIR / "capturas"
DATA_DIR.mkdir(parents=True, exist_ok=True)
CAPTURES_DIR.mkdir(parents=True, exist_ok=True)

DATABASE_PATH = DATA_DIR / "mrepdpc.sqlite3"
DATABASE_URL = f"sqlite:///{DATABASE_PATH.as_posix()}"

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False},
    future=True,
)

SessionLocal = sessionmaker(
    bind=engine,
    autocommit=False,
    autoflush=False,
    expire_on_commit=False,
    class_=Session,
)

Base = declarative_base()


def bootstrap_database(db_engine: Engine) -> None:
    Base.metadata.create_all(bind=db_engine)
    inspector = inspect(db_engine)

    with db_engine.begin() as connection:
        host_columns = (
            {column["name"] for column in inspector.get_columns("host")}
            if inspector.has_table("host")
            else set()
        )
        if "descripcion" not in host_columns:
            connection.execute(
                text("ALTER TABLE host ADD COLUMN descripcion VARCHAR NOT NULL DEFAULT ''")
            )
        if "activo" not in host_columns:
            connection.execute(
                text("ALTER TABLE host ADD COLUMN activo INTEGER NOT NULL DEFAULT 1")
            )

        metric_columns = (
            {column["name"] for column in inspector.get_columns("metrica")}
            if inspector.has_table("metrica")
            else set()
        )
        if "rtt_media_ms" not in metric_columns:
            connection.execute(text("ALTER TABLE metrica ADD COLUMN rtt_media_ms FLOAT"))


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
