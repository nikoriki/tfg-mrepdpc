from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy.orm import Session

from app.models import Configuracion


@dataclass(frozen=True, slots=True)
class RuntimeConfig:

    failure_threshold: int
    capture_interface: str
    capture_duration_seconds: int
    tshark_path: str
    dashboard_refresh_seconds: int
    moving_average_window: int
    ping_timeout_ms: int


DEFAULT_CONFIG = RuntimeConfig(
    failure_threshold=3,
    capture_interface="Ethernet",
    capture_duration_seconds=10,
    tshark_path="tshark",
    dashboard_refresh_seconds=5,
    moving_average_window=5,
    ping_timeout_ms=1000,
)


def ensure_default_configuration(session: Session) -> Configuracion:
    config = session.get(Configuracion, 1)
    if config is None:
        config = Configuracion(
            id=1,
            failure_threshold=DEFAULT_CONFIG.failure_threshold,
            capture_interface=DEFAULT_CONFIG.capture_interface,
            capture_duration_seconds=DEFAULT_CONFIG.capture_duration_seconds,
            tshark_path=DEFAULT_CONFIG.tshark_path,
            dashboard_refresh_seconds=DEFAULT_CONFIG.dashboard_refresh_seconds,
            moving_average_window=DEFAULT_CONFIG.moving_average_window,
            ping_timeout_ms=DEFAULT_CONFIG.ping_timeout_ms,
        )
        session.add(config)
        session.commit()
        session.refresh(config)
    return config


def get_runtime_config(session: Session) -> RuntimeConfig:
    config = ensure_default_configuration(session)
    return RuntimeConfig(
        failure_threshold=config.failure_threshold,
        capture_interface=config.capture_interface,
        capture_duration_seconds=config.capture_duration_seconds,
        tshark_path=config.tshark_path,
        dashboard_refresh_seconds=config.dashboard_refresh_seconds,
        moving_average_window=config.moving_average_window,
        ping_timeout_ms=config.ping_timeout_ms,
    )
