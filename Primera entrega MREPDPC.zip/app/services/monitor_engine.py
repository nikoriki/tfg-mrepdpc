from __future__ import annotations

import asyncio
import logging
import os
import re
import shutil
import subprocess
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Callable

from sqlalchemy import select
from sqlalchemy.orm import Session, sessionmaker

from app.database import BASE_DIR, CAPTURES_DIR
from app.models import Host, Incidente, Metrica
from app.services.config_service import RuntimeConfig

PingFunc = Callable[[str, float], float | None]
PcapPathBuilder = Callable[[str, datetime], str]
CaptureLauncher = Callable[[list[str]], None]

logger = logging.getLogger(__name__)

WINDOWS_TIME_RE = re.compile(r"(?:time[=<]|Average = )\s*(\d+(?:\.\d+)?)\s*(?:ms)?", re.IGNORECASE)
UNIX_TIME_RE = re.compile(r"time[=<]?\s*(\d+(?:\.\d+)?)\s*ms", re.IGNORECASE)


def utc_now() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


@dataclass(frozen=True, slots=True)
class HostProbeConfig:

    ip: str
    intervalo_seg: int


class NetworkMonitorEngine:

    def __init__(
        self,
        session_factory: sessionmaker[Session],
        ping_func: PingFunc | None = None,
        runtime_config: RuntimeConfig | None = None,
        pcap_path_builder: PcapPathBuilder | None = None,
        capture_launcher: CaptureLauncher | None = None,
    ) -> None:
        self.session_factory = session_factory
        self.ping_func = ping_func or self._default_ping
        self.pcap_path_builder = pcap_path_builder or self._default_pcap_path_builder
        self.capture_launcher = capture_launcher or self._default_capture_launcher

        self.failure_counts: dict[str, int] = {}
        self.open_incident_ids: dict[str, int] = {}
        self.next_probe_at: dict[str, datetime] = {}

        self._host_tasks: dict[str, asyncio.Task[None]] = {}
        self._stop_event = asyncio.Event()
        self._running = False
        self._set_runtime_config(runtime_config or RuntimeConfig(3, "Ethernet", 10, "tshark", 5, 5, 1000))

    @property
    def is_running(self) -> bool:
        return self._running

    def apply_runtime_config(self, runtime_config: RuntimeConfig) -> None:
        self._set_runtime_config(runtime_config)

    async def start(self) -> None:
        if self._running:
            return

        hosts = await self._load_hosts()
        self._stop_event = asyncio.Event()
        self._host_tasks = {
            host.ip: asyncio.create_task(
                self._run_host_loop(host), name=f"probe:{host.ip}"
            )
            for host in hosts
        }
        self._running = True

    async def stop(self) -> None:
        if not self._running:
            return

        self._stop_event.set()
        if self._host_tasks:
            await asyncio.gather(*self._host_tasks.values(), return_exceptions=True)

        self._host_tasks.clear()
        self._running = False

    async def reload_hosts(self) -> None:
        await self.stop()
        self.failure_counts.clear()
        self.open_incident_ids.clear()
        self.next_probe_at.clear()
        await self.start()

    async def run_probe_cycle_once(self, force: bool = False) -> None:
        hosts = await self._load_hosts()
        if not hosts:
            return

        await asyncio.gather(*(self._probe_host(host, force=force) for host in hosts))

    def _set_runtime_config(self, runtime_config: RuntimeConfig) -> None:
        self.failure_threshold = max(1, runtime_config.failure_threshold)
        self.capture_interface = runtime_config.capture_interface
        self.capture_duration_seconds = max(1, runtime_config.capture_duration_seconds)
        self.tshark_path = runtime_config.tshark_path
        self.dashboard_refresh_seconds = runtime_config.dashboard_refresh_seconds
        self.moving_average_window = max(1, runtime_config.moving_average_window)
        self.default_timeout = max(runtime_config.ping_timeout_ms, 100) / 1000

    async def _run_host_loop(self, host: HostProbeConfig) -> None:
        interval = max(1, host.intervalo_seg)

        while not self._stop_event.is_set():
            await self._probe_host(host, force=True)
            try:
                await asyncio.wait_for(self._stop_event.wait(), timeout=interval)
            except TimeoutError:
                continue

    async def _probe_host(self, host: HostProbeConfig, force: bool) -> None:
        now = utc_now()
        interval = max(1, host.intervalo_seg)

        if not force:
            due_at = self.next_probe_at.get(host.ip)
            if due_at is not None and now < due_at:
                return

        self.next_probe_at[host.ip] = now + timedelta(seconds=interval)

        rtt = await self._ping(host.ip)
        perdida = 1 if rtt is None else 0
        await asyncio.to_thread(
            self._store_metric_sync, host.ip, rtt or 0.0, perdida, now
        )

        if perdida == 1:
            await self._handle_failure(host.ip, now)
        else:
            await self._handle_success(host.ip, now)

    async def _handle_failure(self, host_ip: str, occurred_at: datetime) -> None:
        failures = self.failure_counts.get(host_ip, 0) + 1
        self.failure_counts[host_ip] = failures

    async def _handle_success(self, host_ip: str, recovered_at: datetime) -> None:
        self.failure_counts[host_ip] = 0

    async def _ping(self, host_ip: str) -> float | None:
        try:
            return await asyncio.to_thread(
                self.ping_func, host_ip, self.default_timeout
            )
        except Exception:
            logger.exception("Ping execution failed for host %s", host_ip)
            return None

    async def _load_hosts(self) -> list[HostProbeConfig]:
        return await asyncio.to_thread(self._load_hosts_sync)

    def _load_hosts_sync(self) -> list[HostProbeConfig]:
        with self.session_factory() as session:
            hosts = session.scalars(select(Host).where(Host.activo.is_(True))).all()

        return [
            HostProbeConfig(ip=host.ip, intervalo_seg=max(1, host.intervalo_seg))
            for host in hosts
        ]

    def _store_metric_sync(
        self, host_ip: str, rtt: float, perdida: int, fecha: datetime
    ) -> None:
        with self.session_factory() as session:
            moving_average = None
            if perdida == 0:
                previous_rtts = session.scalars(
                    select(Metrica.rtt)
                    .where(Metrica.host_ip == host_ip, Metrica.perdida == 0)
                    .order_by(Metrica.fecha.desc())
                    .limit(max(0, self.moving_average_window - 1))
                ).all()
                values = [float(rtt), *[float(value) for value in previous_rtts]]
                moving_average = round(sum(values) / len(values), 2)

            session.add(
                Metrica(
                    host_ip=host_ip,
                    rtt=float(rtt),
                    perdida=perdida,
                    rtt_media_ms=moving_average,
                    fecha=fecha,
                )
            )
            session.commit()

    def _open_incident_sync(self, host_ip: str, started_at: datetime) -> int:
        with self.session_factory() as session:
            active_incident = session.scalar(
                select(Incidente)
                .where(Incidente.host_ip == host_ip)
                .where(Incidente.fin.is_(None))
                .order_by(Incidente.id.desc())
            )
            if active_incident is not None:
                return active_incident.id

            incident = Incidente(
                host_ip=host_ip,
                inicio=started_at,
                fin=None,
                pcap_path=self.pcap_path_builder(host_ip, started_at),
            )
            session.add(incident)
            session.commit()
            session.refresh(incident)

            command = self._build_tshark_command(incident.pcap_path)
            try:
                self.capture_launcher(command)
            except OSError as error:
                logger.warning(
                    "No se pudo lanzar tshark para %s: %s",
                    host_ip,
                    error,
                )

            return incident.id

    def _close_incident_sync(self, incident_id: int, recovered_at: datetime) -> None:
        with self.session_factory() as session:
            incident = session.get(Incidente, incident_id)
            if incident is None:
                return
            if incident.fin is None:
                incident.fin = recovered_at
                session.commit()

    @staticmethod
    def _default_pcap_path_builder(host_ip: str, timestamp: datetime) -> str:
        CAPTURES_DIR.mkdir(parents=True, exist_ok=True)
        stamp = timestamp.strftime("%Y%m%d_%H%M%S")
        return f"capturas/{host_ip}_incidente_{stamp}.pcap"

    @staticmethod
    def _default_ping(host_ip: str, timeout: float) -> float | None:
        timeout_ms = max(int(timeout * 1000), 100)
        if os.name == "nt":
            command = ["ping", "-n", "1", "-w", str(timeout_ms), host_ip]
            parser = WINDOWS_TIME_RE
        else:
            timeout_seconds = max(1, round(timeout))
            command = ["ping", "-c", "1", "-W", str(timeout_seconds), host_ip]
            parser = UNIX_TIME_RE

        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            check=False,
            encoding="utf-8",
            errors="ignore",
        )
        if completed.returncode != 0:
            return None

        output = completed.stdout or completed.stderr
        match = parser.search(output)
        if match is None:
            return None
        return float(match.group(1))

    def _build_tshark_command(self, pcap_path: str) -> list[str]:
        output_path = str((BASE_DIR / pcap_path).resolve())
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        return [
            self.tshark_path,
            "-i",
            self.capture_interface,
            "-a",
            f"duration:{self.capture_duration_seconds}",
            "-w",
            output_path,
        ]

    @staticmethod
    def _default_capture_launcher(command: list[str]) -> None:
        executable = command[0]
        if not shutil.which(executable) and not Path(executable).exists():
            raise FileNotFoundError(
                f"No se encontro tshark en la ruta configurada: {executable}"
            )
        subprocess.Popen(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
