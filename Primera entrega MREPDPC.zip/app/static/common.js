const formatDate = (value) => {
  if (!value) {
    return "-";
  }

  return new Date(value).toLocaleString("es-ES");
};

const statusClass = (estado) => {
  if (estado === "Up") return "status up";
  if (estado === "Down") return "status down";
  if (estado === "Inactivo") return "status off";
  return "status idle";
};

const escapeHtml = (value) =>
  String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");

async function apiFetch(url, options = {}) {
  const response = await fetch(url, {
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
    ...options,
  });

  if (response.status === 204) {
    return null;
  }

  if (!response.ok) {
    let detail = "Error de servidor";
    try {
      const payload = await response.json();
      detail = payload.detail || detail;
    } catch (_error) {
      detail = response.statusText || detail;
    }
    throw new Error(detail);
  }

  return response.json();
}

function setFeedback(elementId, message, isError = false) {
  const element = document.getElementById(elementId);
  if (!element) return;
  element.textContent = message;
  element.style.color = isError ? "#ff7f8f" : "#57d0ff";
}
