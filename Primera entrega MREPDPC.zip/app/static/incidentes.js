async function loadIncidentHosts() {
  const hosts = await apiFetch("/api/hosts");
  const select = document.getElementById("incident-host-filter");
  for (const host of hosts) {
    const option = document.createElement("option");
    option.value = host.ip;
    option.textContent = `${host.ip} - ${host.nombre}`;
    select.appendChild(option);
  }
}

async function loadIncidents() {
  const params = new URLSearchParams();
  const host = document.getElementById("incident-host-filter").value;
  const onlyOpen = document.getElementById("incident-open-filter").value;
  const limit = document.getElementById("incident-limit").value;

  if (host) params.set("host_ip", host);
  params.set("solo_abiertos", onlyOpen);
  if (limit) params.set("limit", limit);

  try {
    const incidents = await apiFetch(`/api/incidentes?${params.toString()}`);
    const tbody = document.getElementById("incidents-table");
    tbody.innerHTML = "";

    if (incidents.length === 0) {
      tbody.innerHTML = "<tr><td colspan='7'>No hay incidentes con ese filtro.</td></tr>";
      return;
    }

    for (const incident of incidents) {
      const downloadLink = incident.pcap_disponible
        ? `<a class="button" href="/api/incidentes/${incident.id}/descargar-pcap">Descargar</a>`
        : "<span class='muted'>No disponible</span>";
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${incident.id}</td>
        <td class="code">${escapeHtml(incident.host_ip)}</td>
        <td>${formatDate(incident.inicio)}</td>
        <td>${formatDate(incident.fin)}</td>
        <td><span class="${statusClass(incident.estado === "Abierto" ? "Down" : "Up")}">${escapeHtml(incident.estado)}</span></td>
        <td class="code">${escapeHtml(incident.pcap_path)}</td>
        <td>${downloadLink}</td>
      `;
      tbody.appendChild(row);
    }
    setFeedback("incidents-feedback", `${incidents.length} incidentes cargados.`);
  } catch (error) {
    setFeedback("incidents-feedback", error.message, true);
  }
}

document.getElementById("load-incidents").addEventListener("click", loadIncidents);

loadIncidentHosts().then(loadIncidents);
