function renderResumen(resumen) {
  document.getElementById("total-hosts").textContent = resumen.total_hosts;
  document.getElementById("hosts-activos").textContent = resumen.hosts_activos;
  document.getElementById("hosts-down").textContent = resumen.hosts_down;
  document.getElementById("metricas-24h").textContent = resumen.metricas_ultimas_24h;
}

function renderHosts(hosts) {
  const tbody = document.getElementById("hosts-body");
  tbody.innerHTML = "";

  if (hosts.length === 0) {
    tbody.innerHTML = "<tr><td colspan='6'>No hay hosts configurados.</td></tr>";
    return;
  }

  for (const host of hosts) {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td class="code">${escapeHtml(host.ip)}</td>
      <td>${escapeHtml(host.nombre)}</td>
      <td><span class="${statusClass(host.estado)}">${escapeHtml(host.estado)}</span></td>
      <td>${host.ultimo_rtt ? `${host.ultimo_rtt.toFixed(2)} ms` : "-"}</td>
      <td>${host.rtt_media_ms ? `${host.rtt_media_ms.toFixed(2)} ms` : "-"}</td>
      <td>${formatDate(host.ultima_fecha)}</td>
    `;
    tbody.appendChild(row);
  }
}

async function loadDashboard() {
  try {
    const [resumen, hosts] = await Promise.all([
      apiFetch("/api/resumen"),
      apiFetch("/api/estado-hosts"),
    ]);
    renderResumen(resumen);
    renderHosts(hosts);
  } catch (error) {
    console.error(error);
  }
}

document.getElementById("reload-dashboard").addEventListener("click", loadDashboard);
loadDashboard();
