async function loadHostDetail() {
  try {
    const detail = await apiFetch(`/api/hosts/${encodeURIComponent(window.HOST_IP)}`);

    document.getElementById("host-summary").innerHTML = `
      <div class="list-item"><strong>IP:</strong> <span class="code">${escapeHtml(detail.host.ip)}</span></div>
      <div class="list-item"><strong>Nombre:</strong> ${escapeHtml(detail.host.nombre)}</div>
      <div class="list-item"><strong>Grupo:</strong> ${escapeHtml(detail.host.grupo)}</div>
      <div class="list-item"><strong>Descripcion:</strong> ${escapeHtml(detail.host.descripcion || "-")}</div>
    `;

    document.getElementById("host-status").innerHTML = `
      <div class="list-item"><strong>Estado:</strong> <span class="${statusClass(detail.estado_actual.estado)}">${escapeHtml(detail.estado_actual.estado)}</span></div>
      <div class="list-item"><strong>Intervalo:</strong> ${detail.estado_actual.intervalo_seg}s</div>
      <div class="list-item"><strong>Ultimo RTT:</strong> ${detail.estado_actual.ultimo_rtt ? `${detail.estado_actual.ultimo_rtt.toFixed(2)} ms` : "-"}</div>
      <div class="list-item"><strong>Media movil:</strong> ${detail.estado_actual.rtt_media_ms ? `${detail.estado_actual.rtt_media_ms.toFixed(2)} ms` : "-"}</div>
    `;

    const metricsBody = document.getElementById("host-metrics");
    metricsBody.innerHTML = "";
    if (detail.metricas.length === 0) {
      metricsBody.innerHTML = "<tr><td colspan='4'>No hay metricas.</td></tr>";
    } else {
      for (const metric of detail.metricas) {
        const row = document.createElement("tr");
        row.innerHTML = `
          <td>${formatDate(metric.fecha)}</td>
          <td>${metric.perdida ? "-" : `${metric.rtt.toFixed(2)} ms`}</td>
          <td>${metric.perdida ? "1" : "0"}</td>
          <td>${metric.rtt_media_ms ? `${metric.rtt_media_ms.toFixed(2)} ms` : "-"}</td>
        `;
        metricsBody.appendChild(row);
      }
    }

    const incidentsBody = document.getElementById("host-incidents");
    incidentsBody.innerHTML = "";
    if (detail.incidentes.length === 0) {
      incidentsBody.innerHTML = "<tr><td colspan='5'>No hay incidentes.</td></tr>";
    } else {
      for (const incident of detail.incidentes) {
        const row = document.createElement("tr");
        row.innerHTML = `
          <td>${incident.id}</td>
          <td>${formatDate(incident.inicio)}</td>
          <td>${formatDate(incident.fin)}</td>
          <td>${escapeHtml(incident.estado)}</td>
          <td>${incident.pcap_disponible ? `<a class="button" href="/api/incidentes/${incident.id}/descargar-pcap">Descargar</a>` : "<span class='muted'>No</span>"}</td>
        `;
        incidentsBody.appendChild(row);
      }
    }
  } catch (error) {
    setFeedback("host-feedback", error.message, true);
  }
}

loadHostDetail();
