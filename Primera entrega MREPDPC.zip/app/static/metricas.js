async function loadMetricHosts() {
  const hosts = await apiFetch("/api/hosts");
  const select = document.getElementById("metrics-host-filter");
  for (const host of hosts) {
    const option = document.createElement("option");
    option.value = host.ip;
    option.textContent = `${host.ip} - ${host.nombre}`;
    select.appendChild(option);
  }
}

function toIsoValue(localValue) {
  if (!localValue) return "";
  return new Date(localValue).toISOString();
}

async function loadMetrics() {
  const params = new URLSearchParams();
  const host = document.getElementById("metrics-host-filter").value;
  const limit = document.getElementById("metrics-limit").value;
  const from = toIsoValue(document.getElementById("metrics-from").value);
  const to = toIsoValue(document.getElementById("metrics-to").value);

  if (host) params.set("host_ip", host);
  if (limit) params.set("limit", limit);
  if (from) params.set("desde", from);
  if (to) params.set("hasta", to);

  try {
    const metrics = await apiFetch(`/api/metricas?${params.toString()}`);
    const tbody = document.getElementById("metrics-table");
    tbody.innerHTML = "";

    if (metrics.length === 0) {
      tbody.innerHTML = "<tr><td colspan='5'>No hay metricas para el filtro actual.</td></tr>";
      return;
    }

    for (const metric of metrics) {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${formatDate(metric.fecha)}</td>
        <td class="code">${escapeHtml(metric.host_ip)}</td>
        <td>${metric.perdida ? "-" : `${metric.rtt.toFixed(2)} ms`}</td>
        <td>${metric.perdida ? "1" : "0"}</td>
        <td>${metric.rtt_media_ms ? `${metric.rtt_media_ms.toFixed(2)} ms` : "-"}</td>
      `;
      tbody.appendChild(row);
    }
    setFeedback("metrics-feedback", `${metrics.length} metricas cargadas.`);
  } catch (error) {
    setFeedback("metrics-feedback", error.message, true);
  }
}

document.getElementById("load-metrics").addEventListener("click", loadMetrics);

loadMetricHosts().then(loadMetrics);
