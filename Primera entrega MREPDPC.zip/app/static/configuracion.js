async function loadConfig() {
  try {
    const config = await apiFetch("/api/configuracion");
    document.getElementById("cfg-failure-threshold").value = config.failure_threshold;
    document.getElementById("cfg-capture-interface").value = config.capture_interface;
    document.getElementById("cfg-capture-duration").value = config.capture_duration_seconds;
    document.getElementById("cfg-tshark-path").value = config.tshark_path;
    document.getElementById("cfg-dashboard-refresh").value = config.dashboard_refresh_seconds;
    document.getElementById("cfg-moving-average").value = config.moving_average_window;
    document.getElementById("cfg-ping-timeout").value = config.ping_timeout_ms;
  } catch (error) {
    setFeedback("config-feedback", error.message, true);
  }
}

document.getElementById("config-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = {
    failure_threshold: Number(document.getElementById("cfg-failure-threshold").value),
    capture_interface: document.getElementById("cfg-capture-interface").value.trim(),
    capture_duration_seconds: Number(document.getElementById("cfg-capture-duration").value),
    tshark_path: document.getElementById("cfg-tshark-path").value.trim(),
    dashboard_refresh_seconds: Number(document.getElementById("cfg-dashboard-refresh").value),
    moving_average_window: Number(document.getElementById("cfg-moving-average").value),
    ping_timeout_ms: Number(document.getElementById("cfg-ping-timeout").value),
  };

  try {
    await apiFetch("/api/configuracion", {
      method: "PUT",
      body: JSON.stringify(payload),
    });
    setFeedback("config-feedback", "Configuracion guardada.");
  } catch (error) {
    setFeedback("config-feedback", error.message, true);
  }
});

document.getElementById("config-reload").addEventListener("click", async () => {
  try {
    const result = await apiFetch("/api/monitor/reload", { method: "POST" });
    setFeedback("config-feedback", result.status);
  } catch (error) {
    setFeedback("config-feedback", error.message, true);
  }
});

loadConfig();
