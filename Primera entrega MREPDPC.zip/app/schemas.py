from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class HostBase(BaseModel):

    nombre: str = Field(min_length=1, max_length=100)
    grupo: str = Field(min_length=1, max_length=100)
    descripcion: str = Field(default="", max_length=255)
    intervalo_seg: int = Field(ge=1, le=3600)
    activo: bool = True


class HostCreate(HostBase):

    ip: str = Field(min_length=1, max_length=50)


class HostUpdate(HostBase):
    pass


class HostRead(HostCreate):

    model_config = ConfigDict(from_attributes=True)


class MetricaRead(BaseModel):

    id: int
    host_ip: str
    rtt: float
    perdida: int
    rtt_media_ms: float | None
    fecha: datetime

    model_config = ConfigDict(from_attributes=True)


class IncidenteRead(BaseModel):

    id: int
    host_ip: str
    inicio: datetime
    fin: datetime | None
    pcap_path: str
    estado: str
    pcap_disponible: bool

    model_config = ConfigDict(from_attributes=True)


class ResumenRead(BaseModel):

    total_hosts: int
    hosts_activos: int
    hosts_down: int
    incidentes_abiertos: int
    metricas_ultimas_24h: int


class HostEstadoRead(BaseModel):

    ip: str
    nombre: str
    grupo: str
    descripcion: str
    activo: bool
    intervalo_seg: int
    estado: str
    ultimo_rtt: float | None
    rtt_media_ms: float | None
    ultima_fecha: datetime | None


class HostDetailRead(BaseModel):

    host: HostRead
    estado_actual: HostEstadoRead
    metricas: list[MetricaRead]
    incidentes: list[IncidenteRead]


class ConfiguracionBase(BaseModel):

    failure_threshold: int = Field(ge=1, le=10)
    capture_interface: str = Field(min_length=1, max_length=100)
    capture_duration_seconds: int = Field(ge=1, le=300)
    tshark_path: str = Field(min_length=1, max_length=255)
    dashboard_refresh_seconds: int = Field(ge=2, le=60)
    moving_average_window: int = Field(ge=1, le=20)
    ping_timeout_ms: int = Field(ge=100, le=5000)


class ConfiguracionRead(ConfiguracionBase):

    id: int

    model_config = ConfigDict(from_attributes=True)


class ConfiguracionUpdate(ConfiguracionBase):
    pass


class MonitorReloadRead(BaseModel):

    status: str
    monitor_activo: bool
