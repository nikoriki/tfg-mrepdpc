from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy import Boolean, CheckConstraint, DateTime, Float, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


def utc_now() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


class Host(Base):

    __tablename__ = "host"

    ip: Mapped[str] = mapped_column(String, primary_key=True)
    nombre: Mapped[str] = mapped_column(String, nullable=False)
    grupo: Mapped[str] = mapped_column(String, nullable=False)
    descripcion: Mapped[str] = mapped_column(String, nullable=False, default="")
    intervalo_seg: Mapped[int] = mapped_column(Integer, nullable=False)
    activo: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    metricas: Mapped[list["Metrica"]] = relationship(
        back_populates="host",
        cascade="all, delete-orphan",
    )
    incidentes: Mapped[list["Incidente"]] = relationship(
        back_populates="host",
        cascade="all, delete-orphan",
    )


class Metrica(Base):

    __tablename__ = "metrica"
    __table_args__ = (CheckConstraint("perdida IN (0, 1)", name="ck_metrica_perdida"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    host_ip: Mapped[str] = mapped_column(
        ForeignKey("host.ip"), nullable=False, index=True
    )
    rtt: Mapped[float] = mapped_column(Float, nullable=False)
    perdida: Mapped[int] = mapped_column(Integer, nullable=False)
    rtt_media_ms: Mapped[float | None] = mapped_column(Float, nullable=True)
    fecha: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=utc_now
    )

    host: Mapped[Host] = relationship(back_populates="metricas")


class Incidente(Base):

    __tablename__ = "incidente"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    host_ip: Mapped[str] = mapped_column(
        ForeignKey("host.ip"), nullable=False, index=True
    )
    inicio: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=utc_now
    )
    fin: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    pcap_path: Mapped[str] = mapped_column(String, nullable=False)

    host: Mapped[Host] = relationship(back_populates="incidentes")


class Configuracion(Base):

    __tablename__ = "configuracion"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, default=1)
    failure_threshold: Mapped[int] = mapped_column(Integer, nullable=False, default=3)
    capture_interface: Mapped[str] = mapped_column(String, nullable=False, default="Ethernet")
    capture_duration_seconds: Mapped[int] = mapped_column(Integer, nullable=False, default=10)
    tshark_path: Mapped[str] = mapped_column(String, nullable=False, default="tshark")
    dashboard_refresh_seconds: Mapped[int] = mapped_column(Integer, nullable=False, default=5)
    moving_average_window: Mapped[int] = mapped_column(Integer, nullable=False, default=5)
    ping_timeout_ms: Mapped[int] = mapped_column(Integer, nullable=False, default=1000)
