from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

BASE_PATH = Path(__file__).resolve().parent.parent
templates = Jinja2Templates(directory=str(BASE_PATH / "templates"))

router = APIRouter(tags=["pages"])


def _context(request: Request, title: str, active_page: str) -> dict[str, object]:
    return {
        "request": request,
        "title": title,
        "active_page": active_page,
        "milestone_label": "Entrega parcial 50%",
    }


@router.get("/", response_class=HTMLResponse, include_in_schema=False)
def root(request: Request) -> HTMLResponse:
    return templates.TemplateResponse(request, "dashboard.html", _context(request, "Dashboard", "dashboard"))


@router.get("/dashboard", response_class=HTMLResponse, include_in_schema=False)
def dashboard_page(request: Request) -> HTMLResponse:
    return templates.TemplateResponse(request, "dashboard.html", _context(request, "Dashboard", "dashboard"))


@router.get("/hosts", response_class=HTMLResponse, include_in_schema=False)
def hosts_page(request: Request) -> HTMLResponse:
    return templates.TemplateResponse(request, "hosts.html", _context(request, "Hosts", "hosts"))


@router.get("/metricas", response_class=HTMLResponse, include_in_schema=False)
def metricas_page(request: Request) -> HTMLResponse:
    return templates.TemplateResponse(request, "metricas.html", _context(request, "Metricas", "metricas"))
