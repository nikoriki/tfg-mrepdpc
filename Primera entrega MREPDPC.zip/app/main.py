from __future__ import annotations

import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from app.database import SessionLocal, bootstrap_database, engine
from app.routers.api import router as api_router
from app.routers.pages import router as pages_router
from app.services.config_service import get_runtime_config
from app.services.monitor_engine import NetworkMonitorEngine

BASE_PATH = Path(__file__).resolve().parent
STATIC_PATH = BASE_PATH / "static"


def create_app(disable_monitor: bool | None = None) -> FastAPI:
    monitor_disabled = disable_monitor
    if monitor_disabled is None:
        monitor_disabled = os.getenv("MREPDPC_DISABLE_MONITOR", "0") == "1"

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        bootstrap_database(engine)
        monitor = None
        with SessionLocal() as session:
            runtime_config = get_runtime_config(session)
        if not monitor_disabled:
            monitor = NetworkMonitorEngine(
                session_factory=SessionLocal,
                runtime_config=runtime_config,
            )
            await monitor.start()
        app.state.monitor = monitor
        yield
        if monitor is not None:
            await monitor.stop()

    app = FastAPI(
        title="MREPDPC",
        description="Monitor de Red para Entornos Privados con Deteccion Proactiva de Caidas",
        version="1.0.0",
        lifespan=lifespan,
    )
    app.mount("/static", StaticFiles(directory=str(STATIC_PATH)), name="static")

    @app.get("/health")
    def health() -> dict[str, str]:
        return {"status": "ok"}

    app.include_router(api_router)
    app.include_router(pages_router)
    return app


app = create_app()
