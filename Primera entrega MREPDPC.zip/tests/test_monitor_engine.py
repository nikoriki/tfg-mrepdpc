from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from sqlalchemy import Engine, create_engine, func, select
from sqlalchemy.orm import Session, sessionmaker

from app.database import Base
from app.models import Host, Incidente, Metrica
from app.services.config_service import RuntimeConfig
from app.services.monitor_engine import NetworkMonitorEngine


def _build_session_factory(db_file: Path) -> tuple[Engine, sessionmaker[Session]]:
    engine = create_engine(
        f"sqlite:///{db_file.as_posix()}",
        connect_args={"check_same_thread": False},
        future=True,
    )
    Base.metadata.create_all(bind=engine)
    factory = sessionmaker(bind=engine, autocommit=False, autoflush=False, expire_on_commit=False, future=True)
    return engine, factory


class MonitorEngineTests(unittest.IsolatedAsyncioTestCase):

    async def asyncSetUp(self) -> None:
        self._tmp_dir = tempfile.TemporaryDirectory()
        self.db_file = Path(self._tmp_dir.name) / "test_mrepdpc.sqlite3"
        self.engine, self.session_factory = _build_session_factory(self.db_file)

        with self.session_factory() as session:
            session.add(
                Host(
                    ip="10.0.0.10",
                    nombre="Host Prueba",
                    grupo="laboratorio",
                    descripcion="Equipo de pruebas",
                    intervalo_seg=1,
                    activo=True,
                )
            )
            session.commit()

        self.runtime_config = RuntimeConfig(3, "Ethernet", 10, "tshark", 5, 3, 1000)

    async def asyncTearDown(self) -> None:
        self.engine.dispose()
        self._tmp_dir.cleanup()

    async def test_failures_do_not_open_incidents_yet(self) -> None:
        sequence = [None, None, None]

        def fake_ping(_ip: str, _timeout: float = 1.0) -> float | None:
            return sequence.pop(0)

        monitor = NetworkMonitorEngine(
            session_factory=self.session_factory,
            ping_func=fake_ping,
            runtime_config=self.runtime_config,
        )

        for _ in range(3):
            await monitor.run_probe_cycle_once(force=True)

        with self.session_factory() as session:
            metric_count = session.scalar(select(func.count()).select_from(Metrica))
            incident_count = session.scalar(select(func.count()).select_from(Incidente))

        self.assertEqual(metric_count, 3)
        self.assertEqual(incident_count, 0)

    async def test_successful_probes_store_moving_average(self) -> None:
        sequence = [10.0, 20.0, 30.0]

        def fake_ping(_ip: str, _timeout: float = 1.0) -> float | None:
            return sequence.pop(0)

        monitor = NetworkMonitorEngine(
            session_factory=self.session_factory,
            ping_func=fake_ping,
            runtime_config=self.runtime_config,
        )

        for _ in range(3):
            await monitor.run_probe_cycle_once(force=True)

        with self.session_factory() as session:
            metrics = session.scalars(select(Metrica).order_by(Metrica.id.asc())).all()

        self.assertEqual(metrics[0].rtt_media_ms, 10.0)
        self.assertEqual(metrics[1].rtt_media_ms, 15.0)
        self.assertEqual(metrics[2].rtt_media_ms, 20.0)


if __name__ == "__main__":
    unittest.main()
