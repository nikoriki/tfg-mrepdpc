from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient
from sqlalchemy import Engine, create_engine
from sqlalchemy.orm import Session, sessionmaker

from app.database import Base, get_db
from app.main import create_app
from app.models import Host, Metrica


def _build_session_factory(db_file: Path) -> tuple[Engine, sessionmaker[Session]]:
    engine = create_engine(
        f"sqlite:///{db_file.as_posix()}",
        connect_args={"check_same_thread": False},
        future=True,
    )
    Base.metadata.create_all(bind=engine)
    factory = sessionmaker(bind=engine, autocommit=False, autoflush=False, expire_on_commit=False, future=True)
    return engine, factory


class ApiEndpointsTests(unittest.TestCase):

    def setUp(self) -> None:
        self._tmp_dir = tempfile.TemporaryDirectory()
        self.db_file = Path(self._tmp_dir.name) / "test_api.sqlite3"
        self.engine, self.session_factory = _build_session_factory(self.db_file)

        with self.session_factory() as session:
            session.add(
                Host(
                    ip="192.168.1.1",
                    nombre="Router",
                    grupo="infraestructura",
                    descripcion="Router principal",
                    intervalo_seg=5,
                    activo=True,
                )
            )
            session.add(Metrica(host_ip="192.168.1.1", rtt=3.5, perdida=0, rtt_media_ms=3.5))
            session.commit()

        def override_get_db() -> Session:
            db = self.session_factory()
            try:
                yield db
            finally:
                db.close()

        self.app = create_app(disable_monitor=True)
        self.app.dependency_overrides[get_db] = override_get_db
        self.client = TestClient(self.app)

    def tearDown(self) -> None:
        self.app.dependency_overrides.clear()
        self.engine.dispose()
        self._tmp_dir.cleanup()

    def test_dashboard_page_renders(self) -> None:
        response = self.client.get("/dashboard")
        self.assertEqual(response.status_code, 200)
        self.assertIn("Dashboard", response.text)

    def test_create_host_and_list_metrics(self) -> None:
        created = self.client.post(
            "/api/hosts",
            json={
                "ip": "8.8.8.8",
                "nombre": "Google DNS",
                "grupo": "internet",
                "descripcion": "Externo",
                "intervalo_seg": 10,
                "activo": True,
            },
        )
        self.assertEqual(created.status_code, 201)

        metrics = self.client.get("/api/metricas")
        self.assertEqual(metrics.status_code, 200)
        self.assertGreaterEqual(len(metrics.json()), 1)

    def test_resumen_endpoint_returns_core_fields(self) -> None:
        response = self.client.get("/api/resumen")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("total_hosts", data)
        self.assertIn("hosts_activos", data)
        self.assertIn("metricas_ultimas_24h", data)


if __name__ == "__main__":
    unittest.main()
