from __future__ import annotations

import asyncio

from app.database import SessionLocal, bootstrap_database, engine
from app.services.config_service import get_runtime_config
from app.services.monitor_engine import NetworkMonitorEngine


async def main() -> None:
    bootstrap_database(engine)
    with SessionLocal() as session:
        runtime_config = get_runtime_config(session)

    monitor = NetworkMonitorEngine(
        session_factory=SessionLocal,
        runtime_config=runtime_config,
    )
    await monitor.start()
    print("Motor de monitorizacion iniciado. Pulsa Ctrl+C para detenerlo.")

    try:
        while True:
            await asyncio.sleep(1)
    finally:
        await monitor.stop()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("Monitor detenido.")
