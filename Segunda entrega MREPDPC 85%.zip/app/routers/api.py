from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.database import BASE_DIR, get_db
from app.models import Configuracion, Host, Incidente, Metrica
from app.schemas import (
    ConfiguracionRead,
    ConfiguracionUpdate,
    HostCreate,
    HostDetailRead,
    HostEstadoRead,
    HostRead,
    HostUpdate,
    IncidenteRead,
    MetricaRead,
    MonitorReloadRead,
    ResumenRead,
)
from app.services.config_service import ensure_default_configuration, get_runtime_config

router = APIRouter(prefix="/api", tags=["api"])


def utc_now() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


def _estado_from_metric(host: Host, metric: Metrica | None) -> HostEstadoRead:
    if not host.activo:
        estado = "Inactivo"
        ultimo_rtt = None
        rtt_media = None
        ultima_fecha = metric.fecha if metric else None
    elif metric is None:
        estado = "Sin datos"
        ultimo_rtt = None
        rtt_media = None
        ultima_fecha = None
    elif metric.perdida == 1:
        estado = "Down"
        ultimo_rtt = None
        rtt_media = metric.rtt_media_ms
        ultima_fecha = metric.fecha
    else:
        estado = "Up"
        ultimo_rtt = metric.rtt
        rtt_media = metric.rtt_media_ms
        ultima_fecha = metric.fecha

    return HostEstadoRead(
        ip=host.ip,
        nombre=host.nombre,
        grupo=host.grupo,
        descripcion=host.descripcion,
        activo=host.activo,
        intervalo_seg=host.intervalo_seg,
        estado=estado,
        ultimo_rtt=ultimo_rtt,
        rtt_media_ms=rtt_media,
        ultima_fecha=ultima_fecha,
    )


def _serialize_incidente(incident: Incidente) -> IncidenteRead:
    file_path = BASE_DIR / incident.pcap_path
    return IncidenteRead(
        id=incident.id,
        host_ip=incident.host_ip,
        inicio=incident.inicio,
        fin=incident.fin,
        pcap_path=incident.pcap_path,
        estado="Abierto" if incident.fin is None else "Cerrado",
        pcap_disponible=file_path.exists(),
    )


@router.get("/hosts", response_model=list[HostRead])
def list_hosts(db: Session = Depends(get_db)) -> list[Host]:
    return db.scalars(select(Host).order_by(Host.grupo.asc(), Host.ip.asc())).all()


@router.get("/hosts/{host_ip}", response_model=HostDetailRead)
def get_host_detail(
    host_ip: str,
    limit_metricas: int = Query(default=20, ge=1, le=200),
    limit_incidentes: int = Query(default=20, ge=1, le=200),
    db: Session = Depends(get_db),
) -> HostDetailRead:
    host = db.get(Host, host_ip)
    if host is None:
        raise HTTPException(status_code=404, detail="Host not found")

    metricas = db.scalars(
        select(Metrica)
        .where(Metrica.host_ip == host_ip)
        .order_by(Metrica.fecha.desc())
        .limit(limit_metricas)
    ).all()
    incidentes = db.scalars(
        select(Incidente)
        .where(Incidente.host_ip == host_ip)
        .order_by(Incidente.inicio.desc())
        .limit(limit_incidentes)
    ).all()

    return HostDetailRead(
        host=HostRead.model_validate(host),
        estado_actual=_estado_from_metric(host, metricas[0] if metricas else None),
        metricas=[MetricaRead.model_validate(item) for item in metricas],
        incidentes=[_serialize_incidente(item) for item in incidentes],
    )


@router.post("/hosts", response_model=HostRead, status_code=status.HTTP_201_CREATED)
def create_host(payload: HostCreate, db: Session = Depends(get_db)) -> Host:
    existing = db.get(Host, payload.ip)
    if existing is not None:
        raise HTTPException(status_code=409, detail="Host already exists")

    host = Host(**payload.model_dump())
    db.add(host)
    db.commit()
    db.refresh(host)
    return host


@router.put("/hosts/{host_ip}", response_model=HostRead)
def update_host(
    host_ip: str, payload: HostUpdate, db: Session = Depends(get_db)
) -> Host:
    host = db.get(Host, host_ip)
    if host is None:
        raise HTTPException(status_code=404, detail="Host not found")

    host.nombre = payload.nombre
    host.grupo = payload.grupo
    host.descripcion = payload.descripcion
    host.intervalo_seg = payload.intervalo_seg
    host.activo = payload.activo
    db.commit()
    db.refresh(host)
    return host


@router.delete(
    "/hosts/{host_ip}",
    status_code=status.HTTP_204_NO_CONTENT,
    response_class=Response,
)
def delete_host(host_ip: str, db: Session = Depends(get_db)) -> Response:
    host = db.get(Host, host_ip)
    if host is None:
        raise HTTPException(status_code=404, detail="Host not found")

    db.delete(host)
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get("/metricas", response_model=list[MetricaRead])
def list_metricas(
    host_ip: str | None = Query(default=None),
    desde: datetime | None = Query(default=None),
    hasta: datetime | None = Query(default=None),
    limit: int = Query(default=100, ge=1, le=500),
    db: Session = Depends(get_db),
) -> list[Metrica]:
    query = select(Metrica)
    if host_ip:
        query = query.where(Metrica.host_ip == host_ip)
    if desde:
        query = query.where(Metrica.fecha >= desde)
    if hasta:
        query = query.where(Metrica.fecha <= hasta)

    query = query.order_by(Metrica.fecha.desc()).limit(limit)
    return db.scalars(query).all()


@router.get("/incidentes", response_model=list[IncidenteRead])
def list_incidentes(
    host_ip: str | None = Query(default=None),
    solo_abiertos: bool = Query(default=False),
    limit: int = Query(default=100, ge=1, le=500),
    db: Session = Depends(get_db),
) -> list[IncidenteRead]:
    query = select(Incidente)
    if host_ip:
        query = query.where(Incidente.host_ip == host_ip)
    if solo_abiertos:
        query = query.where(Incidente.fin.is_(None))

    incidents = db.scalars(query.order_by(Incidente.inicio.desc()).limit(limit)).all()
    return [_serialize_incidente(item) for item in incidents]


@router.get("/incidentes/{incident_id}", response_model=IncidenteRead)
def get_incidente(incident_id: int, db: Session = Depends(get_db)) -> IncidenteRead:
    incident = db.get(Incidente, incident_id)
    if incident is None:
        raise HTTPException(status_code=404, detail="Incident not found")
    return _serialize_incidente(incident)


@router.get("/configuracion", response_model=ConfiguracionRead)
def get_configuracion(db: Session = Depends(get_db)) -> Configuracion:
    return ensure_default_configuration(db)


@router.put("/configuracion", response_model=ConfiguracionRead)
def update_configuracion(
    payload: ConfiguracionUpdate,
    db: Session = Depends(get_db),
) -> Configuracion:
    config = ensure_default_configuration(db)
    for field, value in payload.model_dump().items():
        setattr(config, field, value)
    db.commit()
    db.refresh(config)
    return config


@router.post("/monitor/reload", response_model=MonitorReloadRead)
async def reload_monitor(request: Request, db: Session = Depends(get_db)) -> MonitorReloadRead:
    monitor = getattr(request.app.state, "monitor", None)
    if monitor is None:
        return MonitorReloadRead(status="monitor no disponible", monitor_activo=False)

    runtime_config = get_runtime_config(db)
    monitor.apply_runtime_config(runtime_config)
    await monitor.reload_hosts()
    return MonitorReloadRead(status="monitor recargado", monitor_activo=monitor.is_running)


@router.get("/resumen", response_model=ResumenRead)
def get_resumen(db: Session = Depends(get_db)) -> ResumenRead:
    last_24h = utc_now() - timedelta(hours=24)
    hosts = db.scalars(select(Host)).all()
    total_hosts = len(hosts)
    hosts_activos = sum(1 for host in hosts if host.activo)

    latest_metrics = {
        host.ip: db.scalar(
            select(Metrica)
            .where(Metrica.host_ip == host.ip)
            .order_by(Metrica.fecha.desc())
            .limit(1)
        )
        for host in hosts
    }
    hosts_down = sum(
        1
        for host in hosts
        if host.activo
        and (metric := latest_metrics.get(host.ip)) is not None
        and metric.perdida == 1
    )
    incidentes_abiertos = (
        db.scalar(
            select(func.count()).select_from(Incidente).where(Incidente.fin.is_(None))
        )
        or 0
    )
    metricas_ultimas_24h = (
        db.scalar(
            select(func.count()).select_from(Metrica).where(Metrica.fecha >= last_24h)
        )
        or 0
    )

    return ResumenRead(
        total_hosts=total_hosts,
        hosts_activos=hosts_activos,
        hosts_down=hosts_down,
        incidentes_abiertos=incidentes_abiertos,
        metricas_ultimas_24h=metricas_ultimas_24h,
    )


@router.get("/estado-hosts", response_model=list[HostEstadoRead])
def get_estado_hosts(db: Session = Depends(get_db)) -> list[HostEstadoRead]:
    hosts = db.scalars(select(Host).order_by(Host.grupo.asc(), Host.ip.asc())).all()
    result: list[HostEstadoRead] = []

    for host in hosts:
        last_metric = db.scalar(
            select(Metrica)
            .where(Metrica.host_ip == host.ip)
            .order_by(Metrica.fecha.desc())
            .limit(1)
        )
        result.append(_estado_from_metric(host, last_metric))

    return result
