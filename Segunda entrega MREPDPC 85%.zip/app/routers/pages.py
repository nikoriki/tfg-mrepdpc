from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

BASE_PATH = Path(__file__).resolve().parent.parent
templates = Jinja2Templates(directory=str(BASE_PATH / "templates"))

router = APIRouter(tags=["pages"])


def _context(request: Request, title: str, active_page: str, **kwargs: object) -> dict[str, object]:
    context: dict[str, object] = {
        "request": request,
        "title": title,
        "active_page": active_page,
        "milestone_label": "Entrega parcial 85%",
    }
    context.update(kwargs)
    return context


@router.get("/", response_class=HTMLResponse, include_in_schema=False)
def root(request: Request) -> HTMLResponse:
    return templates.TemplateResponse(
        request,
        "dashboard.html",
        _context(request, "Dashboard", "dashboard"),
    )


@router.get("/dashboard", response_class=HTMLResponse, include_in_schema=False)
def dashboard_page(request: Request) -> HTMLResponse:
    return templates.TemplateResponse(
        request,
        "dashboard.html",
        _context(request, "Dashboard", "dashboard"),
    )


@router.get("/hosts", response_class=HTMLResponse, include_in_schema=False)
def hosts_page(request: Request) -> HTMLResponse:
    return templates.TemplateResponse(
        request,
        "hosts.html",
        _context(request, "Hosts", "hosts"),
    )


@router.get("/metricas", response_class=HTMLResponse, include_in_schema=False)
def metricas_page(request: Request) -> HTMLResponse:
    return templates.TemplateResponse(
        request,
        "metricas.html",
        _context(request, "Metricas", "metricas"),
    )


@router.get("/incidentes", response_class=HTMLResponse, include_in_schema=False)
def incidentes_page(request: Request) -> HTMLResponse:
    return templates.TemplateResponse(
        request,
        "incidentes.html",
        _context(request, "Incidentes", "incidentes"),
    )


@router.get("/configuracion", response_class=HTMLResponse, include_in_schema=False)
def configuracion_page(request: Request) -> HTMLResponse:
    return templates.TemplateResponse(
        request,
        "configuracion.html",
        _context(request, "Configuracion", "configuracion"),
    )


@router.get("/hosts/{host_ip}", response_class=HTMLResponse, include_in_schema=False)
def detalle_host_page(request: Request, host_ip: str) -> HTMLResponse:
    return templates.TemplateResponse(
        request,
        "detalle_host.html",
        _context(request, "Detalle de host", "hosts", host_ip=host_ip),
    )
