const hostForm = document.getElementById("host-form");
const hostReset = document.getElementById("host-reset");
const refreshHostsButton = document.getElementById("refresh-hosts");
const reloadMonitorButton = document.getElementById("reload-monitor");

let editingIp = null;

function hostPayloadFromForm() {
  return {
    ip: document.getElementById("host-ip").value.trim(),
    nombre: document.getElementById("host-nombre").value.trim(),
    grupo: document.getElementById("host-grupo").value.trim(),
    descripcion: document.getElementById("host-descripcion").value.trim(),
    intervalo_seg: Number(document.getElementById("host-intervalo").value),
    activo: document.getElementById("host-activo").value === "true",
  };
}

function resetForm() {
  editingIp = null;
  hostForm.reset();
  document.getElementById("host-intervalo").value = 5;
  document.getElementById("host-activo").value = "true";
  document.getElementById("host-ip").disabled = false;
  setFeedback("hosts-feedback", "");
}

function populateForm(host) {
  editingIp = host.ip;
  document.getElementById("host-ip").value = host.ip;
  document.getElementById("host-ip").disabled = true;
  document.getElementById("host-nombre").value = host.nombre;
  document.getElementById("host-grupo").value = host.grupo;
  document.getElementById("host-descripcion").value = host.descripcion || "";
  document.getElementById("host-intervalo").value = host.intervalo_seg;
  document.getElementById("host-activo").value = String(host.activo);
}

async function loadHosts() {
  try {
    const hosts = await apiFetch("/api/hosts");
    const tbody = document.getElementById("hosts-table");
    tbody.innerHTML = "";

    if (hosts.length === 0) {
      tbody.innerHTML = "<tr><td colspan='7'>No hay hosts cargados.</td></tr>";
      return;
    }

    for (const host of hosts) {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td class="code">${escapeHtml(host.ip)}</td>
        <td>${escapeHtml(host.nombre)}</td>
        <td>${escapeHtml(host.grupo)}</td>
        <td>${host.activo ? "Si" : "No"}</td>
        <td>${host.intervalo_seg}s</td>
        <td>${escapeHtml(host.descripcion || "")}</td>
        <td>
          <div class="inline-actions">
            <a class="button secondary" href="/hosts/${encodeURIComponent(host.ip)}">Detalle</a>
            <button class="secondary" data-action="edit" data-ip="${host.ip}">Editar</button>
            <button class="danger" data-action="delete" data-ip="${host.ip}">Borrar</button>
          </div>
        </td>
      `;
      tbody.appendChild(row);
    }

    tbody.querySelectorAll("button[data-action='edit']").forEach((button) => {
      button.addEventListener("click", () => {
        const host = hosts.find((item) => item.ip === button.dataset.ip);
        populateForm(host);
      });
    });

    tbody.querySelectorAll("button[data-action='delete']").forEach((button) => {
      button.addEventListener("click", async () => {
        if (!window.confirm(`Borrar host ${button.dataset.ip}?`)) {
          return;
        }
        await apiFetch(`/api/hosts/${encodeURIComponent(button.dataset.ip)}`, { method: "DELETE" });
        setFeedback("hosts-feedback", "Host eliminado.");
        if (editingIp === button.dataset.ip) resetForm();
        await loadHosts();
      });
    });
  } catch (error) {
    setFeedback("hosts-feedback", error.message, true);
  }
}

hostForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = hostPayloadFromForm();
  try {
    if (editingIp) {
      await apiFetch(`/api/hosts/${encodeURIComponent(editingIp)}`, {
        method: "PUT",
        body: JSON.stringify({
          nombre: payload.nombre,
          grupo: payload.grupo,
          descripcion: payload.descripcion,
          intervalo_seg: payload.intervalo_seg,
          activo: payload.activo,
        }),
      });
      setFeedback("hosts-feedback", "Host actualizado.");
    } else {
      await apiFetch("/api/hosts", {
        method: "POST",
        body: JSON.stringify(payload),
      });
      setFeedback("hosts-feedback", "Host creado.");
    }

    resetForm();
    await loadHosts();
  } catch (error) {
    setFeedback("hosts-feedback", error.message, true);
  }
});

hostReset.addEventListener("click", resetForm);
refreshHostsButton.addEventListener("click", loadHosts);
reloadMonitorButton.addEventListener("click", async () => {
  try {
    const result = await apiFetch("/api/monitor/reload", { method: "POST" });
    setFeedback("reload-feedback", `${result.status}.`);
  } catch (error) {
    setFeedback("reload-feedback", error.message, true);
  }
});

resetForm();
loadHosts();
