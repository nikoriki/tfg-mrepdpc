let dashboardInterval = null;

function renderResumen(resumen) {
  document.getElementById("total-hosts").textContent = resumen.total_hosts;
  document.getElementById("hosts-activos").textContent = resumen.hosts_activos;
  document.getElementById("hosts-down").textContent = resumen.hosts_down;
  document.getElementById("incidentes-abiertos").textContent = resumen.incidentes_abiertos;
}

function renderHosts(hosts) {
  const tbody = document.getElementById("hosts-body");
  tbody.innerHTML = "";

  if (hosts.length === 0) {
    tbody.innerHTML = "<tr><td colspan='6'>No hay hosts configurados.</td></tr>";
    return;
  }

  for (const host of hosts) {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td class="code">${escapeHtml(host.ip)}</td>
      <td>${escapeHtml(host.nombre)}</td>
      <td><span class="${statusClass(host.estado)}">${escapeHtml(host.estado)}</span></td>
      <td>${host.ultimo_rtt ? `${host.ultimo_rtt.toFixed(2)} ms` : "-"}</td>
      <td>${host.rtt_media_ms ? `${host.rtt_media_ms.toFixed(2)} ms` : "-"}</td>
      <td>${formatDate(host.ultima_fecha)}</td>
    `;
    tbody.appendChild(row);
  }
}

function renderIncidentes(incidentes) {
  const list = document.getElementById("incidentes-list");
  list.innerHTML = "";

  if (incidentes.length === 0) {
    list.innerHTML = "<div class='list-item muted'>No hay incidentes abiertos.</div>";
    return;
  }

  for (const incidente of incidentes) {
    const item = document.createElement("div");
    item.className = "list-item";
    item.innerHTML = `
      <strong>${escapeHtml(incidente.host_ip)}</strong>
      <div class="muted">Inicio: ${formatDate(incidente.inicio)}</div>
      <div class="code">${escapeHtml(incidente.pcap_path)}</div>
    `;
    list.appendChild(item);
  }
}

async function loadConfig() {
  const config = await apiFetch("/api/configuracion");
  document.getElementById("refresh-label").textContent = `${config.dashboard_refresh_seconds}s`;
  if (dashboardInterval) {
    clearInterval(dashboardInterval);
  }
  dashboardInterval = setInterval(loadDashboard, config.dashboard_refresh_seconds * 1000);
}

async function loadDashboard() {
  try {
    const [resumen, hosts, incidentes] = await Promise.all([
      apiFetch("/api/resumen"),
      apiFetch("/api/estado-hosts"),
      apiFetch("/api/incidentes?solo_abiertos=true"),
    ]);
    renderResumen(resumen);
    renderHosts(hosts);
    renderIncidentes(incidentes);
  } catch (error) {
    console.error(error);
  }
}

document.getElementById("reload-dashboard").addEventListener("click", loadDashboard);

loadConfig().then(loadDashboard);
