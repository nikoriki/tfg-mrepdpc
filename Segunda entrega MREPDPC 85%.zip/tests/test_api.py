from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient
from sqlalchemy import Engine, create_engine
from sqlalchemy.orm import Session, sessionmaker

from app.database import Base, get_db
from app.main import create_app
from app.models import Configuracion, Host, Incidente, Metrica


def _build_session_factory(db_file: Path) -> tuple[Engine, sessionmaker[Session]]:
    engine = create_engine(
        f"sqlite:///{db_file.as_posix()}",
        connect_args={"check_same_thread": False},
        future=True,
    )
    Base.metadata.create_all(bind=engine)
    factory = sessionmaker(bind=engine, autocommit=False, autoflush=False, expire_on_commit=False, future=True)
    return engine, factory


class ApiEndpointsTests(unittest.TestCase):

    def setUp(self) -> None:
        self._tmp_dir = tempfile.TemporaryDirectory()
        self.db_file = Path(self._tmp_dir.name) / "test_api.sqlite3"
        self.engine, self.session_factory = _build_session_factory(self.db_file)

        with self.session_factory() as session:
            session.add(
                Configuracion(
                    id=1,
                    failure_threshold=3,
                    capture_interface="Ethernet",
                    capture_duration_seconds=10,
                    tshark_path="tshark",
                    dashboard_refresh_seconds=5,
                    moving_average_window=5,
                    ping_timeout_ms=1000,
                )
            )
            session.add(
                Host(
                    ip="192.168.1.1",
                    nombre="Router",
                    grupo="infraestructura",
                    descripcion="Router principal",
                    intervalo_seg=5,
                    activo=True,
                )
            )
            session.add(Metrica(host_ip="192.168.1.1", rtt=3.4, perdida=0, rtt_media_ms=3.4))
            session.add(Incidente(host_ip="192.168.1.1", pcap_path="capturas/test_incident.pcap"))
            session.commit()

        def override_get_db() -> Session:
            db = self.session_factory()
            try:
                yield db
            finally:
                db.close()

        self.app = create_app(disable_monitor=True)
        self.app.dependency_overrides[get_db] = override_get_db
        self.client = TestClient(self.app)

    def tearDown(self) -> None:
        self.app.dependency_overrides.clear()
        self.engine.dispose()
        self._tmp_dir.cleanup()

    def test_dashboard_page_renders(self) -> None:
        response = self.client.get("/dashboard")
        self.assertEqual(response.status_code, 200)
        self.assertIn("Dashboard", response.text)

    def test_host_detail_and_incidents_listing(self) -> None:
        detail = self.client.get("/api/hosts/192.168.1.1")
        self.assertEqual(detail.status_code, 200)
        self.assertEqual(detail.json()["host"]["ip"], "192.168.1.1")

        incidents = self.client.get("/api/incidentes")
        self.assertEqual(incidents.status_code, 200)
        self.assertEqual(len(incidents.json()), 1)

    def test_configuration_update_and_reload_endpoint(self) -> None:
        updated = self.client.put(
            "/api/configuracion",
            json={
                "failure_threshold": 4,
                "capture_interface": "Wi-Fi",
                "capture_duration_seconds": 12,
                "tshark_path": "C:/Program Files/Wireshark/tshark.exe",
                "dashboard_refresh_seconds": 7,
                "moving_average_window": 6,
                "ping_timeout_ms": 1400,
            },
        )
        self.assertEqual(updated.status_code, 200)
        self.assertEqual(updated.json()["capture_interface"], "Wi-Fi")

        reloaded = self.client.post("/api/monitor/reload")
        self.assertEqual(reloaded.status_code, 200)
        self.assertIn("monitor", reloaded.json()["status"])


if __name__ == "__main__":
    unittest.main()
