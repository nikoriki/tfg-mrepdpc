from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from sqlalchemy import Engine, create_engine, func, select
from sqlalchemy.orm import Session, sessionmaker

from app.database import Base
from app.models import Host, Incidente, Metrica
from app.services.config_service import RuntimeConfig
from app.services.monitor_engine import NetworkMonitorEngine


def _build_session_factory(db_file: Path) -> tuple[Engine, sessionmaker[Session]]:
    engine = create_engine(
        f"sqlite:///{db_file.as_posix()}",
        connect_args={"check_same_thread": False},
        future=True,
    )
    Base.metadata.create_all(bind=engine)
    factory = sessionmaker(
        bind=engine,
        autocommit=False,
        autoflush=False,
        expire_on_commit=False,
        future=True,
    )
    return engine, factory


class MonitorEngineTests(unittest.IsolatedAsyncioTestCase):

    async def asyncSetUp(self) -> None:
        self._tmp_dir = tempfile.TemporaryDirectory()
        self.db_file = Path(self._tmp_dir.name) / "test_mrepdpc.sqlite3"
        self.engine, self.session_factory = _build_session_factory(self.db_file)

        with self.session_factory() as session:
            session.add(
                Host(
                    ip="10.0.0.10",
                    nombre="Host Prueba",
                    grupo="laboratorio",
                    descripcion="Equipo de pruebas",
                    intervalo_seg=1,
                    activo=True,
                )
            )
            session.commit()

        self.runtime_config = RuntimeConfig(
            failure_threshold=3,
            capture_interface="Ethernet 2",
            capture_duration_seconds=12,
            tshark_path="C:/Wireshark/tshark.exe",
            dashboard_refresh_seconds=5,
            moving_average_window=3,
            ping_timeout_ms=1000,
        )

    async def asyncTearDown(self) -> None:
        self.engine.dispose()
        self._tmp_dir.cleanup()

    async def test_recovery_before_third_failure_resets_counter(self) -> None:
        sequence = [None, None, 8.2]

        def fake_ping(_ip: str, _timeout: float = 1.0) -> float | None:
            if sequence:
                return sequence.pop(0)
            return 7.0

        monitor = NetworkMonitorEngine(
            session_factory=self.session_factory,
            ping_func=fake_ping,
            capture_launcher=lambda _cmd: None,
            pcap_path_builder=lambda ip, _dt: f"capturas/{ip}_dummy.pcap",
            runtime_config=self.runtime_config,
        )

        for _ in range(3):
            await monitor.run_probe_cycle_once(force=True)

        self.assertEqual(monitor.failure_counts.get("10.0.0.10", 0), 0)

        with self.session_factory() as session:
            metric_count = session.scalar(select(func.count()).select_from(Metrica))
            incident_count = session.scalar(select(func.count()).select_from(Incidente))

        self.assertEqual(metric_count, 3)
        self.assertEqual(incident_count, 0)

    async def test_third_consecutive_failure_opens_and_recovery_closes_incident(self) -> None:
        sequence = [None, None, None, 5.5]

        def fake_ping(_ip: str, _timeout: float = 1.0) -> float | None:
            if sequence:
                return sequence.pop(0)
            return 5.5

        monitor = NetworkMonitorEngine(
            session_factory=self.session_factory,
            ping_func=fake_ping,
            capture_launcher=lambda _cmd: None,
            pcap_path_builder=lambda ip, _dt: f"capturas/{ip}_dummy.pcap",
            runtime_config=self.runtime_config,
        )

        for _ in range(4):
            await monitor.run_probe_cycle_once(force=True)

        self.assertEqual(monitor.failure_counts.get("10.0.0.10", 0), 0)

        with self.session_factory() as session:
            metric_count = session.scalar(select(func.count()).select_from(Metrica))
            incidents = session.scalars(select(Incidente)).all()

        self.assertEqual(metric_count, 4)
        self.assertEqual(len(incidents), 1)
        self.assertIsNotNone(incidents[0].fin)
        self.assertEqual(incidents[0].pcap_path, "capturas/10.0.0.10_dummy.pcap")

    async def test_confirmed_incident_triggers_single_tshark_launch(self) -> None:
        sequence = [None, None, None, None]
        launched_commands: list[list[str]] = []

        def fake_ping(_ip: str, _timeout: float = 1.0) -> float | None:
            if sequence:
                return sequence.pop(0)
            return None

        def fake_capture_launcher(command: list[str]) -> None:
            launched_commands.append(command)

        monitor = NetworkMonitorEngine(
            session_factory=self.session_factory,
            ping_func=fake_ping,
            capture_launcher=fake_capture_launcher,
            pcap_path_builder=lambda ip, _dt: f"capturas/{ip}_dummy.pcap",
            runtime_config=self.runtime_config,
        )

        for _ in range(4):
            await monitor.run_probe_cycle_once(force=True)

        self.assertEqual(len(launched_commands), 1)
        self.assertEqual(
            launched_commands[0],
            [
                "C:/Wireshark/tshark.exe",
                "-i",
                "Ethernet 2",
                "-a",
                "duration:12",
                "-w",
                str(Path("F:/Projects/tfg/entregas/02_entrega_85/programa/capturas/10.0.0.10_dummy.pcap").resolve()),
            ],
        )

    async def test_successful_metrics_store_moving_average(self) -> None:
        sequence = [10.0, 20.0, 30.0]

        def fake_ping(_ip: str, _timeout: float = 1.0) -> float | None:
            return sequence.pop(0)

        monitor = NetworkMonitorEngine(
            session_factory=self.session_factory,
            ping_func=fake_ping,
            capture_launcher=lambda _cmd: None,
            runtime_config=self.runtime_config,
        )

        for _ in range(3):
            await monitor.run_probe_cycle_once(force=True)

        with self.session_factory() as session:
            metrics = session.scalars(select(Metrica).order_by(Metrica.id.asc())).all()

        self.assertEqual(metrics[0].rtt_media_ms, 10.0)
        self.assertEqual(metrics[1].rtt_media_ms, 15.0)
        self.assertEqual(metrics[2].rtt_media_ms, 20.0)


if __name__ == "__main__":
    unittest.main()
